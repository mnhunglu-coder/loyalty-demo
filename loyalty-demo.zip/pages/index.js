import { useState } from "react";

export default function Home() {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [isAdmin, setIsAdmin] = useState(false);
  const [phone, setPhone] = useState("");
  const [points, setPoints] = useState(0);
  const [history, setHistory] = useState([]);
  const [codeInput, setCodeInput] = useState("");
  const [usedCodes, setUsedCodes] = useState([]);

  // 模擬活動驗證碼清單（每個驗證碼只能用一次）
  const validCodes = ["JOIN2025", "EVENT001", "EVENT002", "EVENT003", "EVENT004"];

  // 登入邏輯
  const handleLogin = () => {
    if (phone === "admin") {
      setIsAdmin(true);
      setIsLoggedIn(true);
    } else if (phone.length >= 8) {
      setIsLoggedIn(true);
    } else {
      alert("請輸入正確的手機號碼！");
    }
  };

  // 輸入活動驗證碼
  const handleVerifyCode = () => {
    if (validCodes.includes(codeInput)) {
      if (usedCodes.includes(codeInput)) {
        alert("此驗證碼已經使用過，無法重複集點！");
      } else if (points < 15) {
        setPoints(points + 1);
        setHistory([
          { date: new Date().toLocaleString(), action: `參與活動 +1 點（驗證碼：${codeInput}）` },
          ...history,
        ]);
        setUsedCodes([...usedCodes, codeInput]);
      }
      setCodeInput("");
    } else {
      alert("驗證碼錯誤！");
    }
  };

  // 登出
  const handleLogout = () => {
    setIsLoggedIn(false);
    setIsAdmin(false);
    setPhone("");
    setPoints(0);
    setHistory([]);
    setUsedCodes([]);
  };

  if (!isLoggedIn) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-gray-100">
        <div className="p-6 bg-white shadow rounded-xl w-80">
          <h1 className="text-xl font-bold mb-4 text-center">會員登入</h1>
          <input
            type="text"
            placeholder="輸入手機號碼 / admin"
            value={phone}
            onChange={(e) => setPhone(e.target.value)}
            className="w-full p-2 border rounded mb-3"
          />
          <button
            onClick={handleLogin}
            className="w-full bg-blue-500 text-white py-2 rounded hover:bg-blue-600"
          >
            登入
          </button>
        </div>
      </div>
    );
  }

  if (isAdmin) {
    return (
      <div className="p-6 bg-gray-100 min-h-screen">
        <h1 className="text-2xl font-bold mb-4">🎛️ 後台管理</h1>
        <p className="mb-2">📌 可用活動驗證碼：{validCodes.join(", ")}</p>
        <p className="mb-2">✅ 已使用驗證碼：{usedCodes.join(", ") || "（尚未使用）"}</p>
        <p className="mb-4">👥 總會員數（假資料）：1</p>
        <button
          onClick={handleLogout}
          className="bg-red-500 text-white px-4 py-2 rounded hover:bg-red-600"
        >
          登出
        </button>
      </div>
    );
  }

  return (
    <div className="p-6 bg-gray-100 min-h-screen">
      <h1 className="text-2xl font-bold mb-4">⭐ 集點活動</h1>
      <p className="mb-4">會員：{phone}</p>

      {/* 星星顯示，最多 15 顆 */}
      <div className="flex space-x-1 mb-4">
        {Array.from({ length: 15 }).map((_, i) => (
          <span key={i} className={i < points ? "text-yellow-400 text-2xl" : "text-gray-300 text-2xl"}>
            ★
          </span>
        ))}
      </div>

      {/* 可兌換提示（滿 3 點） */}
      {points >= 3 && (
        <div className="mb-4 p-3 bg-yellow-100 text-yellow-800 rounded-lg">
          🎁 恭喜您集滿 3 點，可以兌換禮物！
        </div>
      )}

      {/* 活動驗證碼輸入 */}
      <div className="mb-4">
        <input
          type="text"
          placeholder="輸入活動驗證碼"
          value={codeInput}
          onChange={(e) => setCodeInput(e.target.value)}
          className="p-2 border rounded mr-2"
        />
        <button
          onClick={handleVerifyCode}
          className="bg-green-500 text-white px-3 py-2 rounded hover:bg-green-600"
        >
          確認
        </button>
      </div>

      {/* 歷史紀錄 */}
      <h2 className="text-lg font-bold mb-2">📜 歷史紀錄</h2>
      <ul className="bg-white p-3 rounded shadow">
        {history.length === 0 && <li className="text-gray-500">尚無紀錄</li>}
        {history.map((item, index) => (
          <li key={index} className="border-b py-1">
            {item.date} - {item.action}
          </li>
        ))}
      </ul>

      <button
        onClick={handleLogout}
        className="mt-6 bg-red-500 text-white px-4 py-2 rounded hover:bg-red-600"
      >
        登出
      </button>
    </div>
  );
}
